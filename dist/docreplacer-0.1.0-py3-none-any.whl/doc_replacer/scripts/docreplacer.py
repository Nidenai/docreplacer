from doc_replacer import catalog
print('Hello, I am DocReplacer')

catalog.cre
def main():
    if __name__ == '__main__':
        main()
