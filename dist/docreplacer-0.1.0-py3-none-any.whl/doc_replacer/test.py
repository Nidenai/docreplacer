import os

homedir = os.path.expanduser("~")
print(homedir)


